/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaDominio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Sergi Aragall
 */
public class CjtAsignaciones {
/**
 * Arraylist on es guarda totes les asignacions realitzades. Creades per la clase controladorDominio, per tal de construir l'horari.
 */
    private Map<FranjaHoraria, Map<capaDatos.Aula, capaDatos.Asignatura>> cjt_asignaciones;  
/**
 * Constructora sense parametres de la clase CjtAsignacion.
 */
    public CjtAsignaciones(){
        cjt_asignaciones = new HashMap<>();
    }
    
    /**
     * Obte l'arraylist d'asignacions de la clase CjtAsignacions.
     * @return Retorna l'arraylist d'asignacions.
     */
    public Map<FranjaHoraria, Map<capaDatos.Aula, capaDatos.Asignatura>> getCjtA(){
        return cjt_asignaciones;
    }
    /**
     * Afegeix un element, en aquest cas una asignacio, a l'arraylist de la clase CjtAsignacions.
     * @param A Asignacion que sera afegida al arraylist d'asignacions.
     */
    public void addelement(FranjaHoraria fh, capaDatos.Aula au, capaDatos.Asignatura a){
        FranjaHoraria fh_aux = new FranjaHoraria(fh.getHoraIni(), fh.getDia());
        for (int i = 0; i < a.getHoraClase(); i++){
            if (!cjt_asignaciones.containsKey(fh_aux)){
                cjt_asignaciones.put(new FranjaHoraria(fh_aux.getHoraIni(), fh_aux.getDia()), new HashMap <>());
            }
            cjt_asignaciones.get(fh_aux).put(au, a);
            fh_aux.seguentHora();
        }
    }
    /**
     * Elimina l'ultim element de l'arraylist d'asignacions de la clase CjtAsignacions.
     */
    public void delelement(FranjaHoraria fh, capaDatos.Aula au, capaDatos.Asignatura a){
       FranjaHoraria fh_aux = new FranjaHoraria(fh.getHoraIni(), fh.getDia());
        for (int i = 0; i < a.getHoraClase(); i++){
            cjt_asignaciones.get(fh_aux).remove(au);
            fh_aux.seguentHora();
      }
    }    
}
